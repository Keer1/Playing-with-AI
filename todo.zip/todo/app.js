// Plagiarism-safe To-Do implementation with different architecture.
(function(){
  const STORAGE_KEY = 'tdx.v1';

  const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

  function parseDate(value){
    if(!value) return null;
    const d = new Date(value + 'T00:00:00');
    return Number.isNaN(d.getTime()) ? null : d;
  }

  function daysUntil(dateStr){
    const d = parseDate(dateStr);
    if(!d) return null;
    const today = new Date();
    today.setHours(0,0,0,0);
    const one = 24*60*60*1000;
    const diff = Math.round((d - today)/one);
    if (diff < 0) return { label: 'Overdue', cls: 'state-bad', n: diff };
    if (diff === 0) return { label: 'Due today', cls: 'state-warn', n: diff };
    return { label: `${diff} day${diff===1?'':'s'} left`, cls: 'state-ok', n: diff };
  }

  const priorityOrder = { high: 0, medium: 1, low: 2 };

  class TaskStore{
    constructor(key){ this.key = key; this.data = this._load(); }
    _load(){
      try{ return JSON.parse(localStorage.getItem(this.key) || '[]'); }
      catch{ return []; }
    }
    _save(){ localStorage.setItem(this.key, JSON.stringify(this.data)); }
    all(){ return [...this.data]; }
    add(task){ this.data.push(task); this._save(); return task; }
    update(id, patch){
      const i = this.data.findIndex(t => t.id === id);
      if (i === -1) return null;
      this.data[i] = { ...this.data[i], ...patch }; this._save(); return this.data[i];
    }
    remove(id){
      this.data = this.data.filter(t => t.id !== id); this._save();
    }
    clearDone(){
      this.data = this.data.filter(t => !t.done); this._save();
    }
  }

  class TaskView{
    constructor(root){
      this.root = root;
      this.empty = document.getElementById('empty_state');
    }
    render(tasks){
      this.root.innerHTML = '';
      if(!tasks.length){
        this.empty.style.display = 'block';
        return;
      }
      this.empty.style.display = 'none';
      const frag = document.createDocumentFragment();
      for (const t of tasks){ frag.appendChild(this._item(t)); }
      this.root.appendChild(frag);
    }
    _item(t){
      const li = document.createElement('li');
      li.className = 'item' + (t.done ? ' done' : '');
      li.dataset.id = t.id;

      const box = document.createElement('input');
      box.type = 'checkbox'; box.checked = !!t.done; box.title = 'Mark complete';

      const body = document.createElement('div');
      const title = document.createElement('p'); title.className = 'title'; title.textContent = t.title;
      const note = document.createElement('p'); note.className = 'note'; note.textContent = t.note || '';
      body.appendChild(title); if (t.note) body.appendChild(note);

      const meta = document.createElement('div'); meta.className = 'meta';
      const pr = document.createElement('span'); pr.className = 'badge ' + (t.priority || 'medium'); pr.textContent = (t.priority || 'medium').toUpperCase();
      meta.appendChild(pr);
      if (t.due){
        const info = daysUntil(t.due);
        const due = document.createElement('span'); due.className = 'badge ' + (info?.cls || 'state-ok'); due.textContent = info?.label || '';
        meta.appendChild(due);
      }
      const created = document.createElement('span'); created.className = 'badge'; created.textContent = new Date(t.created).toLocaleDateString();
      meta.appendChild(created);
      body.appendChild(meta);

      const actions = document.createElement('div'); actions.className = 'actions';
      const btnEdit = document.createElement('button'); btnEdit.textContent = 'Edit';
      const btnDel = document.createElement('button'); btnDel.textContent = 'Delete';
      actions.append(btnEdit, btnDel);

      li.append(box, body, actions);
      return li;
    }
  }

  class App{
    constructor(){
      this.store = new TaskStore(STORAGE_KEY);
      this.view = new TaskView(document.getElementById('list'));

      this.form = document.getElementById('task_form');
      this.inTitle = document.getElementById('in_title');
      this.inDue = document.getElementById('in_due');
      this.inPr = document.getElementById('in_priority');
      this.inNote = document.getElementById('in_note');

      this.fImportance = document.getElementById('f_importance');
      this.fSort = document.getElementById('f_sort');

      this.dialog = document.getElementById('edit_dialog');
      this.edTitle = document.getElementById('ed_title');
      this.edNote = document.getElementById('ed_note');
      this.edDue = document.getElementById('ed_due');
      this.edPr = document.getElementById('ed_priority');
      this.edSave = document.getElementById('ed_save');
      this.edCancel = document.getElementById('ed_cancel');
      this._editingId = null;

      document.getElementById('btn_clear_done').addEventListener('click', () => {
        this.store.clearDone(); this.render();
      });

      this.form.addEventListener('submit', e => {
        e.preventDefault();
        const title = this.inTitle.value.trim();
        if (!title){ alert('Task title is required'); return; }
        const due = this.inDue.value || null;
        if (due && !parseDate(due)){ alert('Invalid due date'); return; }
        const task = {
          id: uid(),
          title, note: this.inNote.value.trim() || '',
          due, priority: (this.inPr.value || 'medium').toLowerCase(),
          done: false, created: Date.now()
        };
        this.store.add(task);
        this.form.reset();
        this.render();
      });

      this.fImportance.addEventListener('change', () => this.render());
      this.fSort.addEventListener('change', () => this.render());

      this.view.root.addEventListener('click', (e) => {
        const li = e.target.closest('.item');
        if (!li) return;
        const id = li.dataset.id;
        if (e.target.matches('input[type="checkbox"]')){
          const checked = e.target.checked;
          this.store.update(id, { done: checked }); this.render();
        }else if (e.target.textContent === 'Delete'){
          this.store.remove(id); this.render();
        }else if (e.target.textContent === 'Edit'){
          this.openEditor(id);
        }
      });

      this.edCancel.addEventListener('click', (e) => {
        e.preventDefault();
        this.dialog.close(); this._editingId = null;
      });
      this.edSave.addEventListener('click', (e) => {
        e.preventDefault();
        if (!this._editingId) return;
        const patch = {
          title: this.edTitle.value.trim(),
          note: this.edNote.value.trim(),
          due: this.edDue.value || null,
          priority: (this.edPr.value || 'medium').toLowerCase()
        };
        if (!patch.title){ alert('Title is required'); return; }
        this.store.update(this._editingId, patch);
        this.dialog.close(); this._editingId = null; this.render();
      });

      this.render();
    }

    openEditor(id){
      const t = this.store.all().find(x => x.id === id);
      if (!t) return;
      this._editingId = id;
      this.edTitle.value = t.title;
      this.edNote.value = t.note || '';
      this.edDue.value = t.due || '';
      this.edPr.value = t.priority || 'medium';
      this.dialog.showModal();
    }

    get filtered(){
      const imp = this.fImportance.value;
      let list = this.store.all();
      if (imp !== 'all'){
        list = list.filter(t => (t.priority || 'medium') === imp);
      }
      const mode = this.fSort.value;
      const byCreated = (a,b) => a.created - b.created;
      const byDue = (a,b) => {
        const da = (parseDate(a.due)?.getTime() ?? Infinity);
        const db = (parseDate(b.due)?.getTime() ?? Infinity);
        return da - db;
      };
      const byPriority = (a,b) => ({high:0,medium:1,low:2})[(a.priority||'medium')] - ({high:0,medium:1,low:2})[(b.priority||'medium')];
      switch(mode){
        case 'created_desc': list.sort((a,b)=> byCreated(b,a)); break;
        case 'created_asc': list.sort(byCreated); break;
        case 'due_asc': list.sort(byDue); break;
        case 'due_desc': list.sort((a,b)=> byDue(b,a)); break;
        case 'priority': list.sort(byPriority); break;
      }
      return list;
    }

    render(){ this.view.render(this.filtered); }
  }

  window.addEventListener('DOMContentLoaded', () => new App());
})();
