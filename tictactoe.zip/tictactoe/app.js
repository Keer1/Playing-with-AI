// Plagiarism-safe Tic-Tac-Toe with different structure and logic.
(() => {
  const boardEl = document.getElementById('board');
  const turnEl = document.getElementById('turn');
  const sX = document.getElementById('s_x');
  const sO = document.getElementById('s_o');
  const sT = document.getElementById('s_tie');
  const btnNew = document.getElementById('btn_new');
  const btnReset = document.getElementById('btn_reset');
  const dlg = document.getElementById('dlg_win');
  const dlgTitle = document.getElementById('dlg_title');
  const dlgMsg = document.getElementById('dlg_msg');
  const dlgClose = document.getElementById('dlg_close');

  const WIN = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];

  const state = {
    cells: Array(9).fill(''),
    turn: 'X',
    active: true,
    scores: { X:0, O:0, T:0 }
  };

  const tiles = [];
  for (let i=0;i<9;i++){
    const b = document.createElement('button');
    b.className = 'tile';
    b.type = 'button';
    b.setAttribute('data-i', i);
    b.setAttribute('role','gridcell');
    b.setAttribute('aria-label','Empty cell');
    b.tabIndex = i===0 ? 0 : -1;
    boardEl.appendChild(b);
    tiles.push(b);
  }

  function setTurnLabel(){ turnEl.textContent = `Turn: ${state.turn}`; }
  function render(){
    tiles.forEach((t, i) => {
      const v = state.cells[i];
      t.textContent = v || '';
      t.classList.toggle('x', v === 'X');
      t.classList.toggle('o', v === 'O');
      t.classList.remove('win');
      t.setAttribute('aria-label', v ? `Cell ${i+1}: ${v}` : `Empty cell ${i+1}`);
    });
    setTurnLabel();
    sX.textContent = state.scores.X;
    sO.textContent = state.scores.O;
    sT.textContent = state.scores.T;
  }

  function play(i){
    if (!state.active || state.cells[i]) return;
    state.cells[i] = state.turn;
    const outcome = evaluate();
    render();
    if (outcome){ showOutcome(outcome); }
    else{
      state.turn = state.turn === 'X' ? 'O' : 'X';
      setTurnLabel();
    }
  }

  function evaluate(){
    for (const line of WIN){
      const [a,b,c] = line;
      const v = state.cells[a];
      if (v && v === state.cells[b] && v === state.cells[c]){
        tiles[a].classList.add('win');
        tiles[b].classList.add('win');
        tiles[c].classList.add('win');
        state.active = false;
        state.scores[v]++;
        return { winner: v, line };
      }
    }
    if (state.cells.every(Boolean)){
      state.active = false;
      state.scores.T++;
      return { tie:true };
    }
    return null;
  }

  function showOutcome(o){
    if (o.winner){
      dlgTitle.textContent = 'We have a winner!';
      dlgMsg.textContent = `Player ${o.winner} wins this round.`;
    }else{
      dlgTitle.textContent = 'Stalemate';
      dlgMsg.textContent = 'This round ended in a tie.';
    }
    dlg.showModal();
  }

  function newRound(){
    state.cells = Array(9).fill('');
    state.turn = 'X';
    state.active = true;
    render();
    tiles[0].focus();
  }

  function resetScores(){
    state.scores = { X:0, O:0, T:0 };
    newRound();
  }

  boardEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.tile');
    if (!btn) return;
    play(Number(btn.dataset.i));
  });

  boardEl.addEventListener('keydown', (e) => {
    const idx = tiles.findIndex(t => t === document.activeElement);
    if (idx < 0) return;
    let next = idx;
    switch(e.key){
      case 'ArrowUp': next = idx - 3; break;
      case 'ArrowDown': next = idx + 3; break;
      case 'ArrowLeft': next = (idx % 3 === 0) ? idx + 2 : idx - 1; break;
      case 'ArrowRight': next = (idx % 3 === 2) ? idx - 2 : idx + 1; break;
      case 'Enter':
      case ' ': e.preventDefault(); play(idx); return;
      default: return;
    }
    e.preventDefault();
    if (next >=0 && next < 9){ tiles[next].focus(); }
  });

  btnNew.addEventListener('click', newRound);
  btnReset.addEventListener('click', resetScores);
  document.getElementById('dlg_close').addEventListener('click', () => dlg.close());

  render();
  tiles[0].focus();
})();
