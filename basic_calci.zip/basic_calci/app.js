// LiteCalc: custom expression parser (shunting-yard) + evaluator.
// Distinct DOM structure, class names, and keyboard handling.
//
// Tokenization supports numbers (with decimals) and + - * / operators.
// Unary minus is handled during tokenization (when '-' follows an operator or start).

(() => {
  const exprEl = document.getElementById('scr-expr');
  const valEl  = document.getElementById('scr-val');
  const pad = document.querySelector('.pad');

  let buffer = ''; // current input string: e.g., "12+3*4"
  let justEvaluated = false;

  function setDisplays(){
    exprEl.textContent = buffer;
    valEl.textContent = previewValue(buffer);
  }

  function clearAll(){
    buffer = '';
    justEvaluated = false;
    setDisplays();
    if (!valEl.textContent || valEl.textContent === '') valEl.textContent = '0';
  }

  function backspace(){
    if (justEvaluated){ clearAll(); return; }
    buffer = buffer.slice(0, -1);
    setDisplays();
    if (!buffer) valEl.textContent = '0';
  }

  function append(val){
    if (justEvaluated && /[0-9.]/.test(val)){
      // Start a fresh number after equals if digit/dot
      buffer = '';
      justEvaluated = false;
    } else if (justEvaluated && /[+\-*/]/.test(val)){
      // Continue using the last result if operator
      const last = valEl.textContent;
      if (last && last !== 'Error'){ buffer = String(last); }
      justEvaluated = false;
    }
    // Disallow consecutive operators except minus as unary handled later
    const lastChar = buffer.slice(-1);
    if (/[+*/]/.test(lastChar) && /[+*/]/.test(val)){
      buffer = buffer.slice(0, -1) + val; // replace operator
    } else {
      buffer += val;
    }
    setDisplays();
  }

  function equals(){
    try{
      const result = evaluate(buffer);
      valEl.textContent = result === undefined ? '0' : String(result);
      exprEl.textContent = buffer;
      justEvaluated = true;
    }catch(e){
      valEl.textContent = 'Error';
      justEvaluated = true;
    }
  }

  // ---- Parsing helpers ----
  function tokenize(src){
    // Produces tokens: {type:'num', value:Number} or {type:'op', value:'+'|'-'|'*'|'/'}
    // Unary minus -> attach to the number (e.g., "-3")
    const tokens = [];
    let i = 0;
    const isDigit = c => /[0-9]/.test(c);
    const isOp = c => /[+\-*/]/.test(c);
    while (i < src.length){
      const c = src[i];
      if (c === ' '){ i++; continue; }
      if (isDigit(c) || c === '.' || (c === '-' && (i === 0 || isOp(src[i-1])))){
        // parse number (possibly starting with unary -)
        let s = c; i++;
        while (i < src.length && (isDigit(src[i]) || src[i] === '.')){
          s += src[i++];
        }
        if (s === '-' || s === '.' || s === '-.'){ throw new Error('bad number'); }
        const n = Number(s);
        if (!Number.isFinite(n)) throw new Error('bad number');
        tokens.push({ type:'num', value: n });
        continue;
      }
      if (isOp(c)){
        tokens.push({ type:'op', value: c });
        i++; continue;
      }
      throw new Error('bad char');
    }
    return tokens;
  }

  function toRPN(tokens){
    const out = [];
    const ops = [];
    const prec = { '+':1, '-':1, '*':2, '/':2 };
    for (const t of tokens){
      if (t.type === 'num'){ out.push(t); }
      else if (t.type === 'op'){
        while (ops.length && prec[ops[ops.length-1].value] >= prec[t.value]){
          out.push(ops.pop());
        }
        ops.push(t);
      }
    }
    while (ops.length) out.push(ops.pop());
    return out;
  }

  function evalRPN(rpn){
    const st = [];
    for (const t of rpn){
      if (t.type === 'num'){ st.push(t.value); continue; }
      const b = st.pop(), a = st.pop();
      if (a === undefined || b === undefined) throw new Error('stack');
      let v;
      switch(t.value){
        case '+': v = a + b; break;
        case '-': v = a - b; break;
        case '*': v = a * b; break;
        case '/': v = b === 0 ? NaN : a / b; break;
      }
      st.push(v);
    }
    if (st.length !== 1 || !Number.isFinite(st[0])) throw new Error('bad eval');
    // limit decimal noise
    return Number(st[0].toFixed(8));
  }

  function evaluate(src){
    if (!src || !src.trim()) return 0;
    const rpn = toRPN(tokenize(src));
    return evalRPN(rpn);
  }

  function previewValue(src){
    try{
      if (!src) return '0';
      const last = src.slice(-1);
      if (/[+\-*/.]/.test(last)) return ''; // don't preview mid-operator
      return String(evaluate(src));
    }catch{
      return '';
    }
  }

  // ---- Event wiring ----
  pad.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const val = b.getAttribute('data-val');
    const act = b.getAttribute('data-act');
    if (val){ append(val); }
    else if (act === 'clear'){ clearAll(); }
    else if (act === 'del'){ backspace(); }
    else if (act === 'equals'){ equals(); }
  });

  // Keyboard support
  document.addEventListener('keydown', (e) => {
    const k = e.key;
    if (/^[0-9]$/.test(k)) append(k);
    else if (/[+\-*/]/.test(k)) append(k);
    else if (k === '.') append('.');
    else if (k === 'Enter' || k === '='){ equals(); }
    else if (k === 'Backspace'){ backspace(); }
    else if (k === 'Escape'){ clearAll(); }
  });

  // init
  clearAll();
})();
